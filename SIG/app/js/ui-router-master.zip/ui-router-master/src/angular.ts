/** @publicapi @module ng1 */ /** */
import * as ng_from_import from 'angular';
/** @hidden */ declare var angular;
/** @hidden */ const ng_from_global = angular;
/** @hidden */ export const ng = ng_from_import && ng_from_import.module ? ng_from_import : ng_from_global;
